package Mobile_Shop.Mobile_shop_Management_system;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("http://localhost:8080")
public class customerController {
	
	@Autowired
	SessionFactory fact;
	
	
	@GetMapping("/getCustomerData")
	 public List<customer_management> getdata() {

		Session session = fact.openSession();
		Criteria cr=session.createCriteria(customer_management.class);

		List< customer_management> list =cr.list(); 

		return list;
	}

	@PostMapping("/addCustomer")
	public String addcustomer (@RequestBody  customer_management cust) {
		Session session=fact.openSession();
		Transaction tr=session.beginTransaction();
		
		session.save(cust);
		tr.commit();
		return "customer added";
		
	}
	
	@DeleteMapping("/deleteCustomer/{id}")
	public  String deletedata(@PathVariable int id) {
		
		Session session=fact.openSession();
		Transaction tr=session.beginTransaction();
		customer_management obj=session.load(customer_management.class, id);
		session.delete(obj);
		tr.commit();
		return "Customer Data Deleted";
	}
	@PutMapping("/updateCostumer")
	public String updateCustomer (@RequestBody  customer_management cust) {
		Session session=fact.openSession();
		Transaction tr=session.beginTransaction();
		
		session.update(cust);
		tr.commit();
		return "Customer updated";
}
	
}
