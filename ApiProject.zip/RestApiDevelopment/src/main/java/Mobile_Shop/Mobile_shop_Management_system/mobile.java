package Mobile_Shop.Mobile_shop_Management_system;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity(name="mobile")
public class mobile {
	 @Id
	 int mo_id;
	 
	 String Brand_name;
	 
	 float Price;
	 
	 @OneToMany(targetEntity = customer_management.class, cascade = CascadeType.ALL)
	 @JoinColumn(name="mob_id")
	 List<customer_management> list;
	public mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public mobile(int mo_id, String brand_name, float price,List<customer_management> list) {
		super();
		this.mo_id = mo_id;
		Brand_name = brand_name;
		Price = price;
		this.list=list;
	}
	public int getMo_id() {
		return mo_id;
	}
	public void setMo_id(int mo_id) {
		this.mo_id = mo_id;
	}
	public String getBrand_name() {
		return Brand_name;
	}
	public void setBrand_name(String brand_name) {
		Brand_name = brand_name;
	}
	public float getPrice() {
		return Price;
	}
	public void setPrice(float price) {
		Price = price;
	}
	public List<customer_management> getList() {
		return list;
	}
	public void setList(List<customer_management> list) {
		this.list = list;
	}
	 
}
